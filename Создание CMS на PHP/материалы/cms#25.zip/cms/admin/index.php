<?php
define('ROOT_DIR', __DIR__);
define('ENV', 'Admin');
require_once '../engine/bootstrap.php';