<?php $this->theme->header();  ?>
    
    <main>
        <div class="container">
            <br><br><br>
            <div style="text-align:center;">
                <h1><i class="icon-heart icons"></i> Welcome to CMS</h1>
                Watch on channel  <a href="https://www.youtube.com/channel/UCOy440HnmqURkjG9CrBi6nw?disable_polymer=true">
                    <i class="icon-social-youtube icons"></i> Developer Start
                </a>
            </div>
        </div>
    </main>

<?php $this->theme->footer();  ?>    
