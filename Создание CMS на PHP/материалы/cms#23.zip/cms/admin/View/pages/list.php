<?php $this->theme->header();  ?>
    
    <main>
        <div class="container">
            <h3>Pages <a href="/admin/pages/create/">Create page</a></h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </main>

<?php $this->theme->footer();  ?>    
