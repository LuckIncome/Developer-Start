Index Template <?= $name; ?>

<?php $this->theme->header(); ?>
<?php $this->theme->footer(); ?>
<?php $this->theme->sidebar(); ?>
<?php $this->theme->component('head'); ?>
<?php $this->theme->block('comments', ['comments' => $comments]); ?>
