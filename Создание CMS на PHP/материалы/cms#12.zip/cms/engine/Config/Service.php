<?php

return [
	Engine\Service\Database\Provider::class,
	Engine\Service\Router\Provider::class,
	Engine\Service\View\Provider::class,
];