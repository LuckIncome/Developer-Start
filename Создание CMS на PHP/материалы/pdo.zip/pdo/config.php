<?php
return [
			'host'     => 'localhost',
			'db_name'  => 'land',
			'username' => 'root',
			'password' => '',
			'charset'  => 'UTF8',
];