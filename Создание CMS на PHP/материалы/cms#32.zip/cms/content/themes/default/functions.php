<?php
// Add css files
Asset::css('vendor/bootstrap/css/bootstrap.min');
Asset::css('css/clean-blog.min');
Asset::css('vendor/font-awesome/css/font-awesome.min');

// Add js scripts
Asset::js('vendor/jquery/jquery.min');
Asset::js('vendor/bootstrap/js/bootstrap.min');
Asset::js('js/jqBootstrapValidation');
Asset::js('js/contact_me');
Asset::js('js/clean-blog.min');