<?php

return [
    'baseUrl'         => 'http://cms.loc',
    'defaultLang'     => 'english',
    'defaultTimezone' => 'America/Chicago',
    'defaultTheme'    => 'default'
];