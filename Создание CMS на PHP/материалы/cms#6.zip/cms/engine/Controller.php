<?php

namespace Engine;

abstract class Controller 
{
	public function __construct($di) 
	{

	}
}