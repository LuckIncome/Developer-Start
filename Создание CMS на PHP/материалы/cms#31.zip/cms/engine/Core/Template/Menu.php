<?php

namespace Engine\Core\Template;

class Menu 
{
	public static function show() {
		
	}
}