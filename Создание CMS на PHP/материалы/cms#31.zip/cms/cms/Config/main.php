<?php

return [
    'baseUrl'         => 'http://cms',
    'defaultLang'     => 'english',
    'defaultTimezone' => 'America/Chicago',
    'defaultTheme'    => 'default'
];