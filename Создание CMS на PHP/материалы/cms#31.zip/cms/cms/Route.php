<?php
/**
* List routes
*/

	$this->router->add('home', '/', 'HomeController:index');