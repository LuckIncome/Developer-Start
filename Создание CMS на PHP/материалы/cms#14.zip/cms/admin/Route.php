<?php
/**
* List routes
*/

	$this->router->add('login', '/admin/login/', 'LoginController:form');
