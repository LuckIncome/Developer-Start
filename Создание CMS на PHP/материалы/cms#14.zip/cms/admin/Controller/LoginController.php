<?php

namespace Admin\Controller;

class LoginController 
{
	public function form() {
		echo 'form';
	}
}