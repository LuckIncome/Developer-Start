<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="/admin/Assets/js/jquery-2.0.3.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
<script src="/admin/Assets/js/bootstrap.min.js"></script>
<script src="/admin/Assets/js/plugins/redactor/redactor.min.js"></script>
<script src="/admin/Assets/js/init.js"></script>
<script src="/admin/Assets/js/page.js"></script>
<script src="/admin/Assets/js/post.js"></script>
<script src="/admin/Assets/js/setting.js"></script>
</body>
</html>