<?php

return [
	'host' => 'localhost',
	'username' => 'root'
];