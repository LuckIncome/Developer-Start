<?php

namespace Engine\Core\Config;

class Config 
{
	public static function item($key, $group = 'items') {

	}
	public static function file($group) {
		
	}
}