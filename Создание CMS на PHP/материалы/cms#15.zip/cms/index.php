<?php
define('ROOT_DIR', __DIR__);
define('ENV', 'Cms');
require_once 'engine/bootstrap.php';