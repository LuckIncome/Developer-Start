<?php
define('ROOT_DIR', __DIR__);
require_once 'engine/bootstrap.php';