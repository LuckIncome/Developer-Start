<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link active" href="/admin/settings/general/">
            General
        </a>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            Appearance
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Themes</a>
            <a class="dropdown-item" href="/admin/settings/appearance/menus/">
                Menus
            </a>
        </div>
    </li>
</ul>