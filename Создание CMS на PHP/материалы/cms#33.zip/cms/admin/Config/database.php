<?php

return [
	'host'     => 'localhost',
	'db_name'  => 'cms',
	'username' => 'root',
	'password' => '',
	'charset'  => 'utf8',
];