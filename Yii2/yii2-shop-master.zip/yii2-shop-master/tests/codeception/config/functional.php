<?php
/**
 * Application configuration shared by all applications functional tests
 */
return [

];