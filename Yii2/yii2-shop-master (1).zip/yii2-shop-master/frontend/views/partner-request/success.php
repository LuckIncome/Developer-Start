<?php
/**
 * @author Albert Gainutdinov <xalbert.einsteinx@gmail.com>
 */

?>

<h3 class="text-center">
    <?= \Yii::t('shop', 'Your partner request was successfully sent.'); ?>
</h3>
