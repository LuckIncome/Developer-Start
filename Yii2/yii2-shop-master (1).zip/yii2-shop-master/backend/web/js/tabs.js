/**
 * @author Albert Gainutdinov <xalbert.einsteinx@gmail.com>
 *
 * This script adds tabs.
 */

$(function () {
    $("#tabs").tabs();
});

